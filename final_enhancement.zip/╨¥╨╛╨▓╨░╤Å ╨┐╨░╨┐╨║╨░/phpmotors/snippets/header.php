
<header>
<div>
    <img src="/phpmotors/images/site/logo.png" alt="Logo image">
</div>

<div class="account">
<!-- <?//php if(isset($cookieFirstname)){
 //echo "<span>Welcome $cookieFirstname</span>";
//} ?> -->

       <!-- Check if the user is logged in and depending on that display Welcome message 
       and Login/Logout link -->
<?php if(($_SESSION['loggedin'])&&(isset($_SESSION['clientData']['clientFirstname']))){
 $clientFirstname = $_SESSION['clientData']['clientFirstname'];
 echo "<span class='welcome'><a href='/phpmotors/accounts'>Welcome $clientFirstname! </a></span>";
 echo "<a href='/phpmotors/accounts?action=Logout' title = 'Logout'>Log out</a>";
} 
    else{
 echo"<a href='/phpmotors/accounts?action=login' title = 'Login form'>My Account</a>";
    };
?>
</div>
</header>