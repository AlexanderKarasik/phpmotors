
<header>
<div>
    <img src="/phpmotors/images/site/logo.png" alt="Logo image">
</div>

<div class="account">
<?php if(isset($_SESSION['clientData']['clientFirstname'])){
    $clientFirstname = $_SESSION['clientData']['clientFirstname'];
    echo "<span>$clientFirstname  &nbsp;|&nbsp;  </span>";
} ?>
<a href="/phpmotors/accounts?action=Logout" title = "Logout">Logout</a> 
</div>
</header>