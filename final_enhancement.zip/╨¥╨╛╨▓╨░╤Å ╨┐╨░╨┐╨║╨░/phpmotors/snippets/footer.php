<footer>
   <p>
   &copy; PHP Motors, All rights reserved.<br>
    All images used are believed to be in "Fair Use".
    Please notify the author if any are not and they will be removed.<br>
   <span class="updated">
    Last Updated: 27 March, 2023
   </span>
   </p>
</footer>