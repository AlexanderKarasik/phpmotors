<?php
// This is the Vehicles controller

// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the functions library
require_once '../library/functions.php';
// Get the PHP Motors model for use as needed
require_once '../model/main-model.php';
// Get the vehicles model
require_once '../model/vehicles-model.php';
// Get the uploads model
require_once '../model/uploads-model.php';
// Get the reviews model
require_once '../model/reviews-model.php';


// Get the array of classifications
$classifications = getClassifications();
// var_dump($classifications);
// 	exit;

// Call navBuild() function that builds navigation, and pass its value to the $navList variable
$navList=navBuild($classifications);

// $classificationList = "<option value=''>Choose car classification</option>";
// foreach ($classifications as $classification) {
//     $classificationList .= "<option value=".urlencode($classification['classificationId']).">$classification[classificationName]</option>";
// };

$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
 if ($action == NULL){
  $action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
 }

 switch ($action){
  case 'regVehicle':
    // Filter and store the data
$classificationId = trim(filter_input(INPUT_POST, 'classificationId', FILTER_SANITIZE_NUMBER_FLOAT));
$invMake = trim(filter_input(INPUT_POST, 'invMake', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$invModel = trim(filter_input(INPUT_POST, 'invModel', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$invDescription = trim(filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$invImage = trim(filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_URL));
$invThumbnail = trim(filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_URL));
$invPrice = trim(filter_input(INPUT_POST, 'invPrice', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION));
$invStock = trim(filter_input(INPUT_POST, 'invStock', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION));
$invColor = trim(filter_input(INPUT_POST, 'invColor', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

// Check for missing data
if(empty($classificationId) || empty($invMake) || empty($invModel) 
|| empty($invDescription) || empty($invImage) || empty($invThumbnail)
|| empty($invPrice) || empty($invStock) || empty($invColor)){
  $message = '<p style="color:rgb(168, 3, 3); margin-top:-5px;"><em>Please provide information for all empty form fields.</em> </p>';
  include '../view/add-vehicle.php';
  exit; 
 };

// Send the data to the model
$insOutcome = insVehicle($classificationId, $invMake, $invModel, $invDescription, $invImage,
$invThumbnail, $invPrice, $invStock, $invColor);

// Check and report the result
if($insOutcome === 1){
  $message = "<p style='margin-top:-5px;'>The $invMake $invModel was added successfully!</p>";
  
  // Clear variables in order to get clear fields in the form after adding a vehicle
  $invImage = "";
  $invModel = "";
  $invMake = "";
  $classificationId = "";
  $invDescription = "";
  $invThumbnail = "";
  $invPrice = "";
  $invStock = "";
  $invColor = "";

  include '../view/add-vehicle.php';
  exit;
 } else {
  $message = "<p>Sorry, but adding the vehicle failed. Please try again.</p>";
  include '../view/add-vehicle.php';
  exit;
 }
    break;

case 'regClassification':
    // Filter and store the data
$classificationName = trim(filter_input(INPUT_POST, 'classificationName', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$checkClassification = checkClassification($classificationName);
// Check for missing data
if(empty($checkClassification)){
    $message = '<p style="color:rgb(168, 3, 3);"><em>Please provide information for empty form field.</em> </p>';
    include '../view/add-classification.php';
    exit; 
    };

// Send the data to the model
$insOutcome = insClassification($classificationName);

// Check and report the result
if($insOutcome === 1){
    header("Location: index.php");
    exit;
    } else {
    $message = "<p>Sorry, but adding the classification failed. Please try again.</p>";
    include '../view/add-classification.php';
    exit;
    }
    break;

 case 'addVehicle':
  include '../view/add-vehicle.php';
  break;

case 'addClassification':
  include '../view/add-classification.php';
  break;

/* * ********************************** 
* Get vehicles by classificationId 
* Used for starting Update & Delete process 
* ********************************** */ 
case 'getInventoryItems': 
  // Get the classificationId 
  $classificationId = filter_input(INPUT_GET, 'classificationId', FILTER_SANITIZE_NUMBER_INT); 
  // Fetch the vehicles by classificationId from the DB 
  $inventoryArray = getInventoryByClassification($classificationId); 
  // Convert the array to a JSON object and send it back 
  echo json_encode($inventoryArray); 
break;

case 'mod':
  $invId = filter_input(INPUT_GET, 'invId', FILTER_VALIDATE_INT); 
  $invInfo = getInvItemInfo($invId);   
  if(count($invInfo)<1){
    $message = 'Sorry, no vehicle information could be found.';
   }  
  include '../view/vehicle-update.php';
  exit; 
break;

case 'updateVehicle':
    // Filter and store the data
  $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);
  $classificationId = trim(filter_input(INPUT_POST, 'classificationId', FILTER_SANITIZE_NUMBER_FLOAT));
  $invMake = trim(filter_input(INPUT_POST, 'invMake', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  $invModel = trim(filter_input(INPUT_POST, 'invModel', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  $invDescription = trim(filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  $invImage = trim(filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_URL));
  $invThumbnail = trim(filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_URL));
  $invPrice = trim(filter_input(INPUT_POST, 'invPrice', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION));
  $invStock = trim(filter_input(INPUT_POST, 'invStock', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION));
  $invColor = trim(filter_input(INPUT_POST, 'invColor', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

  // Check for missing data
  if(empty($classificationId) || empty($invMake) || empty($invModel) 
  || empty($invDescription) || empty($invImage) || empty($invThumbnail)
  || empty($invPrice) || empty($invStock) || empty($invColor)){
    $message = '<p style="color:rgb(168, 3, 3); margin-top:-5px;"><em>Please provide information for all empty form fields.</em> </p>';
    include '../view/vehicle-update.php';
    exit; 
  };

  // Send the data to the model
  $updateResult = updateVehicle($invId, $classificationId, $invMake, $invModel, $invDescription, $invImage,
  $invThumbnail, $invPrice, $invStock, $invColor);

  // Check and report the result
  if($updateResult === 1){
    $message = "<p id='messageUpdate'>The $invMake $invModel was updated successfully!</p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/vehicles/');
    exit;
  } else {
    $message = "<p id='messageUpdateFail'>Sorry, but updating the $invMake $invModel failed. Please try again.</p>";
    include '../view/vehicle-update.php';
    exit;
  }
break;

case 'del':
  $invId = filter_input(INPUT_GET, 'invId', FILTER_VALIDATE_INT); 
  $invInfo = getInvItemInfo($invId);   
  if(count($invInfo)<1){
    $message = 'Sorry, no vehicle information could be found.';
   }  
  include '../view/vehicle-delete.php';
  exit; 
break;

case 'deleteVehicle':
	// Filter and store the data
  $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);
  $invMake = trim(filter_input(INPUT_POST, 'invMake', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  $invModel = trim(filter_input(INPUT_POST, 'invModel', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

  // Send the data to the model
  $deleteResult = deleteVehicle($invId);

  // Check and report the result
  if($deleteResult === 1){
    $message = "<p id='messageUpdate'>The $invMake $invModel was deleted successfully!</p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/vehicles/');
    exit;
  } else {
    $message = "<p id='messageUpdate'>Sorry, the $invMake $invModel delete failed.</p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/vehicles/');
    exit;
  }					
break;

case 'classification':
  $classificationName = filter_input(INPUT_GET, 'classificationName', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
  //Create a variable to store the array of vehicles
  $vehicles = getVehiclesByClassification($classificationName);
  if(!count($vehicles)){
    $message = "<p class='notice'>Sorry, no $classificationName vehicles could be found.</p>";
  } else {
    $vehicleDisplay = buildVehiclesDisplay($vehicles);
  }
  include '../view/classification.php';
  break;

case 'vehicleDetail':
  $invId = filter_input(INPUT_GET, 'invId', FILTER_SANITIZE_NUMBER_INT);
  //Create a variable to store vehicle's details
  $vehicleInfo = getInvItemInfo($invId);
  $thumbImages = getThumbnailPath($invId);
  $vehicleMake = $vehicleInfo['invMake'];
  $vehicleModel = $vehicleInfo['invModel'];
  //Create variables to store client's details
  $clientInfo = $_SESSION['clientData'];
  $clientFirstname = $clientInfo['clientFirstname'];
  $clientLastname = $clientInfo['clientLastname'];
  $firstLetter = ucfirst($clientFirstname[0]);
  $clientLastname =  ucfirst($clientLastname);
  $screenName = "$firstLetter$clientLastname";
  
  if(!count($vehicleInfo)){
    $message = "<p class='notice'>Sorry, no vehicle could be found.</p>";
  } else {
    $thumbDisplay = buildThumbDisplay($thumbImages);
    $vehicleDetailDisplay = buildDetailDisplay($vehicleInfo, $thumbDisplay);    
  }

  //Create a variable to store vehicle's reviews and build HTML around it.
   $reviewList = getReviewsByItem($invId);
   if ($reviewList){
    // var_dump($reviewList);
    $vehicleReviewDisplay = buildReviewDisplay($reviewList);
   };

  include '../view/vehicle-detail.php';
  unset($_SESSION["message"]);
  break;

default:
$classificationList = buildClassificationList($classifications);
  include "../view/vehicle-man.php";
break;
}
?>