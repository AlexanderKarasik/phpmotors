-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 29 2023 г., 22:36
-- Версия сервера: 10.4.27-MariaDB
-- Версия PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `phpmotors`
--

-- --------------------------------------------------------

--
-- Структура таблицы `carclassification`
--

CREATE TABLE `carclassification` (
  `classificationId` int(11) NOT NULL,
  `classificationName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `carclassification`
--

INSERT INTO `carclassification` (`classificationId`, `classificationName`) VALUES
(1, 'SUV'),
(2, 'Classic'),
(3, 'Sports'),
(4, 'Trucks'),
(5, 'Used');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE `clients` (
  `clientId` int(10) UNSIGNED NOT NULL,
  `clientFirstname` varchar(15) NOT NULL,
  `clientLastname` varchar(25) NOT NULL,
  `clientEmail` varchar(40) NOT NULL,
  `clientPassword` varchar(255) NOT NULL,
  `clientLevel` enum('1','2','3') NOT NULL DEFAULT '1',
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`clientId`, `clientFirstname`, `clientLastname`, `clientEmail`, `clientPassword`, `clientLevel`, `comment`) VALUES
(46, 'Alexander', 'Karasik', 'yakarasik@yandex.ru', '$2y$10$gVGkj2jJwalsktiyxE73LuR/LyLNLl0P7igYaEHvNDYCdc2boCgV6', '1', NULL),
(47, 'Alexander', 'f3f', 'uj@mail.ru', '$2y$10$3SO/li/9KLRNrQ/qmeOH0u99yab70cHcW6JpwM45ZCSlO/nDekPnO', '1', NULL),
(49, 'Jack', 'Maldini', 'maldini@gmail.com', '$2y$10$t1guatfl8vlw421etJIMBOVQ/lemCENUXrlsFyger/p9h46JxL3qe', '1', NULL),
(50, 'John', 'Smith', 'smith@gmail.com', '$2y$10$mXtiv.si1Vx8YmYUmbnDsOR1AvD0NIASfp0HQABAH.pgR48YGc746', '1', NULL),
(51, 'Breadley', 'Kooper', 'koop@mail.ru', '$2y$10$.KwTQ3FI7rWt.IdCdvXxCeglaPX6qtQDCgBun594TEOnxRbXMmfqq', '1', NULL),
(52, 'Admin', 'User', 'admin@cse340.net', '$2y$10$MEpEmXKVExLKRkXpvy6zjeNJUSarNrQ6uUJfHed2AzzaROoRYIRO.', '3', NULL),
(53, 'Alexander', 'Karasik', 'email@mail.ru', '$2y$10$96za3xttQbsuZKTmk723iezrUoIUEeaDn44wNjQvIP0ErT5QCmGfC', '1', NULL),
(54, 'Alexander', 'Karasik', 'new@mail.ru', '$2y$10$6JpPS0HxFqlI7UX2tdeu2.dztbc6C.Ch.RsYJ5ltP4kQZ0a3GPKei', '1', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `imgId` int(11) UNSIGNED NOT NULL,
  `invId` int(10) UNSIGNED NOT NULL,
  `imgName` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `imgPath` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `imgDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `imgPrimary` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`imgId`, `invId`, `imgName`, `imgPath`, `imgDate`, `imgPrimary`) VALUES
(27, 1, 'wrangler.jpg', '/phpmotors/images/vehicles/wrangler.jpg', '2023-03-19 16:35:30', 1),
(28, 1, 'wrangler-tn.jpg', '/phpmotors/images/vehicles/wrangler-tn.jpg', '2023-03-19 16:35:30', 1),
(29, 2, 'ford-modelt.jpg', '/phpmotors/images/vehicles/ford-modelt.jpg', '2023-03-19 16:36:01', 1),
(30, 2, 'ford-modelt-tn.jpg', '/phpmotors/images/vehicles/ford-modelt-tn.jpg', '2023-03-19 16:36:01', 1),
(31, 3, 'lambo-Adve.jpg', '/phpmotors/images/vehicles/lambo-Adve.jpg', '2023-03-19 16:36:32', 1),
(32, 3, 'lambo-Adve-tn.jpg', '/phpmotors/images/vehicles/lambo-Adve-tn.jpg', '2023-03-19 16:36:32', 1),
(33, 4, 'monster.jpg', '/phpmotors/images/vehicles/monster.jpg', '2023-03-19 16:37:11', 1),
(34, 4, 'monster-tn.jpg', '/phpmotors/images/vehicles/monster-tn.jpg', '2023-03-19 16:37:11', 1),
(35, 5, 'ms.jpg', '/phpmotors/images/vehicles/ms.jpg', '2023-03-19 16:37:27', 1),
(36, 5, 'ms-tn.jpg', '/phpmotors/images/vehicles/ms-tn.jpg', '2023-03-19 16:37:27', 1),
(37, 6, 'bat.jpg', '/phpmotors/images/vehicles/bat.jpg', '2023-03-19 17:52:35', 1),
(38, 6, 'bat-tn.jpg', '/phpmotors/images/vehicles/bat-tn.jpg', '2023-03-19 17:52:35', 1),
(39, 8, 'fire-truck.jpg', '/phpmotors/images/vehicles/fire-truck.jpg', '2023-03-19 17:53:21', 1),
(40, 8, 'fire-truck-tn.jpg', '/phpmotors/images/vehicles/fire-truck-tn.jpg', '2023-03-19 17:53:21', 1),
(41, 9, 'crown-vic.jpg', '/phpmotors/images/vehicles/crown-vic.jpg', '2023-03-19 17:53:38', 1),
(42, 9, 'crown-vic-tn.jpg', '/phpmotors/images/vehicles/crown-vic-tn.jpg', '2023-03-19 17:53:38', 1),
(43, 10, 'camaro.jpg', '/phpmotors/images/vehicles/camaro.jpg', '2023-03-19 17:53:59', 1),
(44, 10, 'camaro-tn.jpg', '/phpmotors/images/vehicles/camaro-tn.jpg', '2023-03-19 17:53:59', 1),
(45, 11, 'escalade.jpg', '/phpmotors/images/vehicles/escalade.jpg', '2023-03-19 17:54:13', 1),
(46, 11, 'escalade-tn.jpg', '/phpmotors/images/vehicles/escalade-tn.jpg', '2023-03-19 17:54:13', 1),
(47, 12, 'hummer.jpg', '/phpmotors/images/vehicles/hummer.jpg', '2023-03-19 17:54:26', 1),
(48, 12, 'hummer-tn.jpg', '/phpmotors/images/vehicles/hummer-tn.jpg', '2023-03-19 17:54:26', 1),
(53, 15, 'no-image.png', '/phpmotors/images/vehicles/no-image.png', '2023-03-19 17:55:26', 1),
(54, 15, 'no-image-tn.png', '/phpmotors/images/vehicles/no-image-tn.png', '2023-03-19 17:55:26', 1),
(57, 7, 'mm.jpg', '/phpmotors/images/vehicles/mm.jpg', '2023-03-19 18:13:02', 1),
(58, 7, 'mm-tn.jpg', '/phpmotors/images/vehicles/mm-tn.jpg', '2023-03-19 18:13:02', 1),
(59, 14, 'fbi.jpg', '/phpmotors/images/vehicles/fbi.jpg', '2023-03-19 18:19:15', 1),
(60, 14, 'fbi-tn.jpg', '/phpmotors/images/vehicles/fbi-tn.jpg', '2023-03-19 18:19:15', 1),
(61, 46, 'delorean.jpg', '/phpmotors/images/vehicles/delorean.jpg', '2023-03-19 18:27:21', 1),
(62, 46, 'delorean-tn.jpg', '/phpmotors/images/vehicles/delorean-tn.jpg', '2023-03-19 18:27:21', 1),
(63, 13, 'aerocar.jpg', '/phpmotors/images/vehicles/aerocar.jpg', '2023-03-19 18:50:50', 1),
(64, 13, 'aerocar-tn.jpg', '/phpmotors/images/vehicles/aerocar-tn.jpg', '2023-03-19 18:50:50', 1),
(67, 2, 'ford2.jpg', '/phpmotors/images/vehicles/ford2.jpg', '2023-03-20 17:23:02', 0),
(68, 2, 'ford2-tn.jpg', '/phpmotors/images/vehicles/ford2-tn.jpg', '2023-03-20 17:23:02', 0),
(69, 2, 'ford3.jpg', '/phpmotors/images/vehicles/ford3.jpg', '2023-03-20 17:23:14', 0),
(70, 2, 'ford3-tn.jpg', '/phpmotors/images/vehicles/ford3-tn.jpg', '2023-03-20 17:23:14', 0),
(71, 3, 'lambo1.jpg', '/phpmotors/images/vehicles/lambo1.jpg', '2023-03-20 17:23:30', 0),
(72, 3, 'lambo1-tn.jpg', '/phpmotors/images/vehicles/lambo1-tn.jpg', '2023-03-20 17:23:30', 0),
(75, 3, 'lambo3.jpg', '/phpmotors/images/vehicles/lambo3.jpg', '2023-03-20 17:23:53', 0),
(76, 3, 'lambo3-tn.jpg', '/phpmotors/images/vehicles/lambo3-tn.jpg', '2023-03-20 17:23:53', 0),
(77, 12, 'hummer1.jpg', '/phpmotors/images/vehicles/hummer1.jpg', '2023-03-20 17:24:09', 0),
(78, 12, 'hummer1-tn.jpg', '/phpmotors/images/vehicles/hummer1-tn.jpg', '2023-03-20 17:24:09', 0),
(79, 12, 'hummer2.jpg', '/phpmotors/images/vehicles/hummer2.jpg', '2023-03-20 17:24:17', 0),
(80, 12, 'hummer2-tn.jpg', '/phpmotors/images/vehicles/hummer2-tn.jpg', '2023-03-20 17:24:17', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `inventory`
--

CREATE TABLE `inventory` (
  `invId` int(10) UNSIGNED NOT NULL,
  `invMake` varchar(30) NOT NULL,
  `invModel` varchar(30) NOT NULL,
  `invDescription` text NOT NULL,
  `invImage` varchar(50) NOT NULL,
  `invThumbnail` varchar(50) NOT NULL,
  `invPrice` decimal(10,0) NOT NULL,
  `invStock` smallint(6) NOT NULL,
  `invColor` varchar(20) NOT NULL,
  `classificationId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `inventory`
--

INSERT INTO `inventory` (`invId`, `invMake`, `invModel`, `invDescription`, `invImage`, `invThumbnail`, `invPrice`, `invStock`, `invColor`, `classificationId`) VALUES
(1, 'Jeep ', 'Wrangler', 'The Jeep Wrangler is small and compact with enough power to get you where you want to go. It is great for everyday driving as well as off-roading whether that be on the rocks or in the mud!', '/phpmotors/images/vehicles/wrangler.jpg', '/phpmotors/images/vehicles/wrangler-tn.jpg', '28045', 4, 'Orange', 1),
(2, 'Ford', 'Model T', 'The Ford Model T can be a bit tricky to drive. It was the first car to be put into production. You can get it in any color you want if it is black.', '/phpmotors/images/vehicles/ford-modelt.jpg', '/phpmotors/images/vehicles/ford-modelt-tn.jpg', '30000', 2, 'Black', 2),
(3, 'Lamborghini', 'Adventador', 'This V-12 engine packs a punch in this sporty car. Make sure you wear your seatbelt and obey all traffic laws.', '/phpmotors/images/vehicles/lambo-Adve.jpg', '/phpmotors/images/vehicles/lambo-Adve-tn.jpg', '417600', 1, 'Blue', 3),
(4, 'Monster', 'Truck', 'Most trucks are for working, this one is for fun. This beast comes with 60 inch tires giving you the traction needed to jump and roll in the mud.', '/phpmotors/images/vehicles/monster.jpg', '/phpmotors/images/vehicles/monster-tn.jpg', '150000', 3, 'purple', 4),
(5, 'Mechanic', 'Special', 'Not sure where this car came from. However, with a little tender loving care it will run as good a new.', '/phpmotors/images/vehicles/ms.jpg', '/phpmotors/images/vehicles/ms-tn.jpg', '100', 1, 'Rust', 5),
(6, 'Batmobile', 'Custom', 'Ever want to be a superhero? Now you can with the bat mobile. This car allows you to switch to bike mode allowing for easy maneuvering through traffic during rush hour.', '/phpmotors/images/vehicles/bat.jpg', '/phpmotors/images/vehicles/bat-tn.jpg', '65000', 1, 'Black', 3),
(7, 'Mystery', 'Machine', 'Scooby and the gang always found luck in solving their mysteries because of their 4 wheel drive Mystery Machine. This Van will help you do whatever job you are required to with a success rate of 100%.', '/phpmotors/images/vehicles/mm.jpg', '/phpmotors/images/vehicles/mm-tn.jpg', '10000', 12, 'Green', 1),
(8, 'Spartan', 'Fire Truck', 'Emergencies happen often. Be prepared with this Spartan fire truck. Comes complete with 1000 ft. of hose and a 1000-gallon tank.', '/phpmotors/images/vehicles/fire-truck.jpg', '/phpmotors/images/vehicles/fire-truck-tn.jpg', '50000', 1, 'Red', 4),
(9, 'Ford', 'Crown Victoria', 'After the police force updated their fleet these cars are now available to the public! These cars come equipped with the siren which is convenient for college students running late to class.', '/phpmotors/images/vehicles/crown-vic.jpg', '/phpmotors/images/vehicles/crown-vic-tn.jpg', '10000', 5, 'White', 5),
(10, 'Chevy', 'Camaro', 'If you want to look cool this is the car you need! This car has great performance at an affordable price. Own it today!', '/phpmotors/images/vehicles/camaro.jpg', '/phpmotors/images/vehicles/camaro-tn.jpg', '25000', 10, 'Silver', 3),
(11, 'Cadillac', 'Escalade', 'This styling car is great for any occasion from going to the beach to meeting the president. The luxurious inside makes this car a home away from home.', '/phpmotors/images/vehicles/escalade.jpg', '/phpmotors/images/vehicles/escalade-tn.jpg', '75195', 4, 'Black', 1),
(12, 'GM', 'Hummer', 'Do you have 6 kids and like to go off-roading? The Hummer gives you the small interiors with an engine to get you out of any muddy or rocky situation.', '/phpmotors/images/vehicles/hummer.jpg', '/phpmotors/images/vehicles/hummer-tn.jpg', '58800', 5, 'Yellow', 5),
(13, 'Aerocar International', '', 'Are you sick of rush hour traffic? This car converts into an airplane to get you where you are going fast. Only 6 of these were made, get this one while it lasts!', '/phpmotors/images/vehicles/aerocar.jpg', '/phpmotors/images/vehicles/aerocar-tn.jpg', '1000000', 1, 'Red', 2),
(14, 'FBI', 'Surveillance Van', 'Do you like police shows? You will feel right at home driving this van. Comes complete with surveillance equipment for an extra fee of $2,000 a month. ', '/phpmotors/images/vehicles/fbi.jpg', '/phpmotors/images/vehicles/fbi-tn.jpg', '20000', 1, 'Green', 1),
(15, 'Dog', 'Car', 'Do you like dogs? Well, this car is for you straight from the 90s from Aspen, Colorado we have the original Dog Car complete with fluffy ears.', '/phpmotors/images/vehicles/no-image.png', '/phpmotors/images/vehicles/no-image.png', '35000', 1, 'Brown', 2),
(46, 'DMC', 'DeLorean', 'Good old car.', '/phpmotors/images/vehicles/delorean.jpg', '/phpmotors/images/vehicles/delorean-tn.jpg', '10000', 2, 'Black', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `reviewId` int(10) UNSIGNED NOT NULL,
  `reviewText` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `reviewDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `invId` int(10) UNSIGNED NOT NULL,
  `clientId` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`reviewId`, `reviewText`, `reviewDate`, `invId`, `clientId`) VALUES
(1, 'Very nice old car.', '2023-03-25 11:12:25', 2, 46),
(4, 'Very fast and attractive.', '2023-03-25 11:49:48', 3, 46),
(5, 'Funny old car bur real lemon.', '2023-03-25 11:52:47', 14, 46),
(6, 'A car for superhero.', '2023-03-25 12:20:11', 6, 46),
(7, 'Nice but pretty slow and old car. Retro mobile.', '2023-03-25 14:49:04', 2, 46),
(9, 'Good car for flowers business.', '2023-03-25 17:02:57', 14, 46),
(10, 'Strong navy car for strong men.', '2023-03-25 17:04:56', 12, 46),
(11, 'Funny looking car for big happy family.', '2023-03-25 18:05:21', 7, 46),
(12, 'This Van will help you do whatever job you are required to with a success rate of 100%.', '2023-03-25 19:47:49', 7, 46),
(13, 'Emergencies happen often. Be prepared with this Spartan fire truck. Comes complete with 1000 ft. of hose and a 1000-gallon tank..', '2023-03-26 19:50:11', 8, 46),
(14, 'This styling car is great for any occasion from going to the beach to meeting the president. The luxurious inside makes this car a home away from home.', '2023-03-26 19:56:41', 11, 52),
(15, 'Big black car..', '2023-03-26 19:57:25', 11, 52);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `carclassification`
--
ALTER TABLE `carclassification`
  ADD PRIMARY KEY (`classificationId`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`clientId`),
  ADD UNIQUE KEY `clientEmail` (`clientEmail`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`imgId`),
  ADD KEY `invId` (`invId`);

--
-- Индексы таблицы `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`invId`),
  ADD KEY `classificationId` (`classificationId`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`reviewId`),
  ADD KEY `FK_reviews_inventory` (`invId`),
  ADD KEY `FK_reviews_clients` (`clientId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `carclassification`
--
ALTER TABLE `carclassification`
  MODIFY `classificationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `clientId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `imgId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT для таблицы `inventory`
--
ALTER TABLE `inventory`
  MODIFY `invId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `reviewId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `FK_inv_images` FOREIGN KEY (`invId`) REFERENCES `inventory` (`invId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`classificationId`) REFERENCES `carclassification` (`classificationId`);

--
-- Ограничения внешнего ключа таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `FK_reviews_clients` FOREIGN KEY (`clientId`) REFERENCES `clients` (`clientId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_reviews_inventory` FOREIGN KEY (`invId`) REFERENCES `inventory` (`invId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
