-- Query 1
INSERT INTO clients
	(clientFirstname, clientLastname, clientEmail, clientPassword, comment)
VALUES
	('Tony', 'Stark', 'tony@starkent.com', 'Iam1ronM@n', 'I am the real Ironman');

-- Query 2
UPDATE
	clients
SET
	clientLevel  = 3
WHERE clientId = 4 AND clientFirstname = 'Tony';

-- Query 3
UPDATE inventory
SET invDescription = replace(invDescription, 'small', 'spacious')
WHERE invId = 12;

-- Query 4
SELECT inventory.invModel, carclassification.classificationName
FROM inventory
INNER JOIN carclassification
ON inventory.classificationId = carclassification.classificationId
WHERE inventory.classificationId = 1;

-- Query 5
DELETE
FROM
	inventory
WHERE
	invId=1 and invMake='Jeep' and invModel = 'Wrangler';

-- Query 6
UPDATE inventory
SET invImage=concat('/phpmotors', invImage), 
    invThumbnail=concat('/phpmotors', invThumbnail);

--