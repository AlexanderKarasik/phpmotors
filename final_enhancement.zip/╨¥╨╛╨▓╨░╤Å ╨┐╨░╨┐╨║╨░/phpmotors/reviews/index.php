<?php
// This is the reviews controller

// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the functions library
require_once '../library/functions.php';
// Get the PHP Motors model for use as needed
require_once '../model/main-model.php';
// Get the vehicles model
require_once '../model/vehicles-model.php';
// Get the uploads model
require_once '../model/uploads-model.php';
// Get the reviews model
require_once '../model/reviews-model.php';


// Get the array of classifications
$classifications = getClassifications();
// var_dump($classifications);
// 	exit;

// Call navBuild() function that builds navigation, and pass its value to the $navList variable
$navList=navBuild($classifications);

$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
 if ($action == NULL){
  $action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
 }

 switch ($action){
case 'addReview':
    // Filter and store the data
    $reviewText = trim(filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);
    $clientId = $_SESSION['clientData']['clientId'];
    //Create a variable to store vehicle's details and build the view
    // $vehicleInfo = getInvItemInfo($invId);
    // $thumbImages = getThumbnailPath($invId);
    // $vehicleMake = $vehicleInfo['invMake'];
    // $vehicleModel = $vehicleInfo['invModel'];
    // $thumbDisplay = buildThumbDisplay($thumbImages);
    // $vehicleDetailDisplay = buildDetailDisplay($vehicleInfo, $thumbDisplay);
    // $screenNameSes = $_SESSION['screenName'];
    // Check for missing data
    if(empty($reviewText)){
    $message1 = '<p style="color:rgb(168, 3, 3); margin-top:-5px;"><em>Please provide information for empty form field.</em> </p>';
    $_SESSION['message'] = $message1;
    header("location: /phpmotors/vehicles?action=vehicleDetail&invId=$invId") ;
    exit; 
    };

    // Send the data to the model
    $insOutcome = insReview($reviewText, $invId, $clientId);

    // Check and report the result
    if($insOutcome === 1){
    $message1 = "<p style='margin-top:-5px; color:rgb(168, 3, 3)'>The review was added successfully and is available below!</p>";
    $_SESSION['message'] = $message1;
    header("location: /phpmotors/vehicles?action=vehicleDetail&invId=$invId") ;
    exit;
    } else {
    $message1 = "<p>Sorry, but adding the review failed. Please try again.</p>";
    $_SESSION['message'] = $message1;
    header("location: /phpmotors/vehicles?action=vehicleDetail&invId=$invId") ;
    exit;
    }
    break;

case 'edit':
    $reviewId = filter_input(INPUT_GET, 'reviewId', FILTER_VALIDATE_INT); 
    $review = getSpecificReview($reviewId);  
    if(!($review)){
        $message = 'Sorry, no review could be found.';
    }else{
        $displayReview = buildEditView($review); 
     }  
    include '../view/review-update.php';
    exit; 
    break;

case 'Edit':
  // Filter and store the data
  $reviewId = filter_input(INPUT_POST, 'reviewId', FILTER_SANITIZE_NUMBER_INT);
  $reviewText = trim(filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  // Check for missing data
  if(empty($reviewText)){
    $message = '<p style="color:rgb(168, 3, 3); margin-top:-5px;"><em>Please provide information.</em> </p>';
    $_SESSION['message'] = $message;
    header("location: /phpmotors/reviews?action=edit&reviewId=$reviewId");
    exit; 
  }

  // Send the data to the model
  $updateResult = updateReview($reviewId, $reviewText);

  // Check and report the result
  if($updateResult === 1){
    $message = "<p style='color:rgb(168, 3, 3); margin-top:-5px;'><em>The review was updated successfully!</em></p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/accounts/');
    exit;
  } else {
    $message = "<p style='color:rgb(168, 3, 3); margin-top:-5px;'><em>No information have been updated.</em></p>";
    $_SESSION['message'] = $message;
    // header('location: /phpmotors/accounts/');
    header("location: /phpmotors/reviews?action=edit&reviewId=$reviewId");
    exit;
  }
break;

case 'delete':
    $reviewId = filter_input(INPUT_GET, 'reviewId', FILTER_VALIDATE_INT); 
    $review = getSpecificReview($reviewId);  
    if(!($review)){
        $message = 'Sorry, no review could be found.';
    }else{
        $displayReview = buildDeleteView($review); 
     }  
    include '../view/review-delete.php';
    exit; 
    break;

case 'Delete': 
  // Filter and store the data
  $reviewId = filter_input(INPUT_POST, 'reviewId', FILTER_SANITIZE_NUMBER_INT);

  // Send the data to the model
  $deleteResult = deleteReview($reviewId);

  // Check and report the result
  if($deleteResult === 1){
    $message = "<p style='color:rgb(168, 3, 3); margin-top:-5px;'><em>The review was deleted successfully!</em></p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/accounts/');
    exit;
  } else {
    $message = "<p style='color:rgb(168, 3, 3); margin-top:-5px;'><em>Sorry, but review deletion failed. Please try again.</em></p>";
    $_SESSION['message'] = $message;
    header('location: /phpmotors/accounts/');
    exit;
  }
break;

default:
    header("location: /phpmotors/accounts/");
    exit;
break;
}
?>
