<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Login | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Login Form">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="login">
<?php
  if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
   }
  ?>
    <form method="post" action="/phpmotors/accounts/index.php">
        <h1>Sign in</h1>
        <fieldset>
            <label class="top">Email <input type="email" name="clientEmail" <?php if(isset($clientEmail)){echo "value='$clientEmail'";} ?> required></label>
            <span>Password must be at least 8 characters and contain at least 1 number,
                1 capital letter and 1 special character.
            </span>
            <label class="top">Password <input type="password" name="clientPassword" pattern="(?=.*\d)(?=.*\W+)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></label>
            <input type="submit" value="Sign-in" class="submitBtn">
            <input type="hidden" name="action" value="Login">
        </fieldset>
        </form>

        <p><a href="../accounts?action=registration" title = "Register form">Not a member yet?</a></p>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>