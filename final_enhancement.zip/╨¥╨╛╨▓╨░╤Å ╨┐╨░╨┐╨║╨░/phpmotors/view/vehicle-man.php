<?php
// Check if the user is logged in and has clientLevel higher than 1. 
// If not, redirect to the home view.
if (!($_SESSION['loggedin']&&($_SESSION['clientData']['clientLevel']>1))) {
  header('Location: /phpmotors');
    exit;
  }
if (isset($_SESSION['message'])) {
  $message = $_SESSION['message'];
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Management | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Vehicle Management">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="vehicleMan">
    <h1>Vehicle Management</h1>
<ul>
<li><a href="/phpmotors/vehicles?action=addClassification" title = "Add classification">Add classification</a></li>
<li><a href="/phpmotors/vehicles?action=addVehicle" title = "Add vehicle">Add vehicle</a></li>
</ul>

<?php
if (isset($classificationList)) { 
 echo '<h3>Vehicles By Classification</h3>'; 
 if (isset($message)) { 
  echo $message; 
 } 
 echo '<p>Choose a classification to see those vehicles</p>'; 
 echo $classificationList; 
}
?>

<noscript>
<p><strong>JavaScript Must Be Enabled to Use this Page.</strong></p>
</noscript>

<table id="inventoryDisplay"></table>


</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
<script src="../js/inventory.js"></script>
</body>
</html>
<?php unset($_SESSION['message']); ?>
