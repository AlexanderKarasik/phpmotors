<?php
if(!$_SESSION['loggedin']) {
    header('Location: /phpmotors');
    exit;
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Management | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Update Client Form">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="addVehicle">
<h1>Manage Account</h1>
<h3 class='first'>Update Account</h3>
  <?php
  if (isset($message)) {
  echo $message;
  }
  ?>
  
<form method="post" action="/phpmotors/accounts/index.php">
    <label>First Name<input type="text" name="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";} elseif(isset($clientInfo['clientFirstname'])) {echo "value='$clientInfo[clientFirstname]'"; }?> required></label>
    <label>Last Name<input type="text" name="clientLastname" <?php if(isset($clientLastname)){echo "value='$clientLastname'";} elseif(isset($clientInfo['clientLastname'])) {echo "value='$clientInfo[clientLastname]'"; }?> required></label>    
    <label>Email<input type="email" name="clientEmail" <?php if(isset($clientEmail)){echo "value='$clientEmail'";} elseif(isset($clientInfo['clientEmail'])) {echo "value='$clientInfo[clientEmail]'"; }?> required></label>
    <input type="submit" name="submit" value="Update Info" class="submitBtn">  
    <input type="hidden" name="action" value="updateClient">  
    <input type="hidden" name="clientId" value="<?php if(isset($clientInfo['clientId'])){ echo $clientInfo['clientId'];} elseif(isset($clientId)){echo $clientId;}?>"> 
    </form>

<h3 class='second'>Update Password</h3>
<?php
  if (isset($messagePassword)) {
  echo $messagePassword;
  }
  ?>
<p>Password must be at least 8 characters and contain at least 1 number, 1 capital letter and 1 special character.</p>
<p>*note your original password will be changed.</p>

<form method="post" action="/phpmotors/accounts/index.php">
<label>Password<input type="password" name="clientPassword" id="clientPassword" pattern="(?=.*\d)(?=.*\W+)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></label>
<input type="submit" name="submit" value="Update Password" class="submitBtn">  
<input type="hidden" name="action" value="updatePassword">  
<input type="hidden" name="clientId" value="<?php if(isset($clientInfo['clientId'])){ echo $clientInfo['clientId'];} elseif(isset($clientId)){echo $clientId;}?>"> 
</form>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>