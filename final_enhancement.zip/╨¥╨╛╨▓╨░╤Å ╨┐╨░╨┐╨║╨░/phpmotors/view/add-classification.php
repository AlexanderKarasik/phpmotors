<?php
// Check if the user is logged in and has clientLevel higher than 1. 
// If not, redirect to the home view.
if (!($_SESSION['loggedin']&&($_SESSION['clientData']['clientLevel']>1))) {
  header('Location: /phpmotors');
    exit;
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Classification | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Add Classification Form">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="addClassification">
    <form method="post" action="/phpmotors/vehicles/index.php">
        <h1>Add Car Classification</h1>
        <?php
        if (isset($message)) {
        echo $message;
        }
        ?>
        <span>Classification Name must be 30 characters maximum.</span>
        <label class="top">Classification Name <input type="text" name="classificationName" pattern=".{1,30}" required></label>
        <input type="submit" value="Add Classification" class="submitBtn">  
        <input type="hidden" name="action" value="regClassification">     
        </form>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>