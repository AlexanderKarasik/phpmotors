<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Motors Home Page</title>
    <meta
      name="description"
      content="PHP Motors Home Page">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php //require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/navigation.php'; 
echo $navList; ?>
</nav>

<!-- MAIN GOES HERE -->
<section class="main">
<h2>
    Welcome to PHP Motors!
</h2>
<div class="dmc">
<img class="delorean_img" src = "/phpmotors/images/vehicles/delorean.jpg" alt="Car image">
<p>
  <span class="delorean"><b>DMC Delorean</b></span><br>
  3 Cup holders <br>
  Superman doors <br>
  Fuzzy dice!  
</p>
</div>

<div class="own">
<img src = "/phpmotors/images/site/own_today.png" alt="Own button image">
</div>

<div class = "grid">
  <div class = "grid_one">
    <h2>
      DMC Delorean Reviews
    </h2>
    <ul>
      <li>"So fast it's almost like travelling in time." (4/5)</li>
      <li>"Coolest ride on the road" (4/5)</li>
      <li>"I am feeling Marty McFly!" (5/5)</li>
      <li>"The most futuristic ride of our day" (4.5/5)</li>
      <li>"80's livin and I love it! (5/5)"</li>
    </ul>
  </div>

  <div class="grid_two">
    <h2>Delorean Upgrades</h2>
    <div class="grid_upgrades">

    <div class="flux">
    <div class="photo">
        <img src="/phpmotors/images/upgrades/flux-cap.png" alt="Flux image">
      </div>
      <div class="a">
      <a href="#">Flux Capacitor</a>
      </div>
    </div>

    <div class="flame">
    <div class="photo">
        <img src="/phpmotors/images/upgrades/flame.jpg" alt="Flame image">
      </div>
      <div class="a">
      <a href="#">Flame Decals</a>
      </div>
    </div>

    <div class="bumber">
    <div class="photo">
        <img src="/phpmotors/images/upgrades/bumper_sticker.jpg" alt="Sticker image">
      </div>
      <div class="a">
      <a href="#">Flux Capacitor</a>
      </div>
    </div>

    <div class="hub">
    <div class="photo">
        <img src="/phpmotors/images/upgrades/hub-cap.jpg" alt="Hub-Cap image">
      </div>
      <div class="a">
      <a href="#">Flux Capacitor</a>
      </div>
    </div>

    </div>
  </div>
</div>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>