<?php
// Build the select list
$classificationList = "<option value=''>Choose car classification</option>";
foreach ($classifications as $classification) {
    $classificationList .= "<option value='$classification[classificationId]'";
    if (isset($classificationId)){
      if ($classification['classificationId'] == $classificationId){
        $classificationList .= ' selected ';
      }
    } elseif(isset($invInfo['classificationId'])){
        if($classification['classificationId'] == $invInfo['classificationId']){
         $classificationList .= ' selected ';
        }
       }
    $classificationList .=  ">$classification[classificationName]</option>";
};

// Check if the user is logged in and has clientLevel higher than 1. 
// If not, redirect to the home view.
if (!($_SESSION['loggedin']&&($_SESSION['clientData']['clientLevel']>1))) {
  header('Location: /phpmotors');
    exit;
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
		echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Modify $invMake $invModel"; }?> | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Add Vehicle Form">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="addVehicle">
<h1><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
elseif(isset($invMake) && isset($invModel)) { 
	echo "Modify $invMake $invModel"; }?></h1>
  <?php
  if (isset($message)) {
  echo $message;
  }
  ?>
  <p>*Note all Fields are Required</p>
<form method="post" action="/phpmotors/vehicles/index.php">
    <select name="classificationId" required>
    <?php echo $classificationList; ?>
    </select>
    <label>Make<input type="text" name="invMake" <?php if(isset($invMake)){echo "value='$invMake'";} elseif(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?> required></label>
    <label>Model<input type="text" name="invModel" <?php if(isset($invModel)){echo "value='$invModel'";} elseif(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?> required></label>
    <label>Description<textarea name="invDescription" required><?php if(isset($invDescription)){echo $invDescription;} elseif(isset($invInfo['invDescription'])) {echo $invInfo['invDescription']; }?></textarea></label>
    <label>Image Path<input type="text" name="invImage" <?php if(isset($invImage)){echo "value='$invImage'";} elseif(isset($invInfo['invImage'])) {echo "value='$invInfo[invImage]'"; }?> required></label> 
    <label>Thumbnail Path<input type="text" name="invThumbnail" <?php if(isset($invThumbnail)){echo "value='$invThumbnail'";} elseif(isset($invInfo['invThumbnail'])) {echo "value='$invInfo[invThumbnail]'"; }?> required></label>
    <label>Price<input type="number" name="invPrice" <?php if(isset($invPrice)){echo "value='$invPrice'";} elseif(isset($invInfo['invPrice'])) {echo "value='$invInfo[invPrice]'"; }?> required></label>
    <label># In Stock<input type="number" name="invStock" <?php if(isset($invStock)){echo "value='$invStock'";} elseif(isset($invInfo['invStock'])) {echo "value='$invInfo[invStock]'"; }?> required></label>  
    <label>Color<input type="text" name="invColor" <?php if(isset($invColor)){echo "value='$invColor'";} elseif(isset($invInfo['invColor'])) {echo "value='$invInfo[invColor]'"; }?> required></label>    
    <input type="submit" name="submit" value="Update Vehicle" class="submitBtn">  
    <input type="hidden" name="action" value="updateVehicle">  
    <input type="hidden" name="invId" value="<?php if(isset($invInfo['invId'])){ echo $invInfo['invId'];} elseif(isset($invId)){echo $invId;}?>
    "> 
    </form>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>