<?php
if(!$_SESSION['loggedin']) {
    header('Location: /phpmotors');
    exit;
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Admin View">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header_admin.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="admin">
  <?php if(isset($_SESSION['clientData'])){
    $clientFirstname = $_SESSION['clientData']['clientFirstname'];
    $clientLastname = $_SESSION['clientData']['clientLastname'];
    $clientEmail = $_SESSION['clientData']['clientEmail'];
    $clientLevel = $_SESSION['clientData']['clientLevel'];
    echo "<h1>$clientFirstname $clientLastname</h1>";
    echo "<p>You are logged in.</p>";
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
       }
    echo "<ul><li>First name: $clientFirstname</li><li>Last name: $clientLastname</li>
    <li>Email: $clientEmail</li></ul>";    

    echo"<h3>Account Management</h3>";
    echo"<p>Use this link to update account information</p>";
    echo"<p><a href='/phpmotors/accounts?action=modClient&clientEmail=$clientEmail' title='Click to modify'>Update Account Information</a></p>";

if(($clientLevel)>1){
    echo "<h3 id='invHeading'>Inventory Management</h3>";
    echo "<p>Use this link to manage the inventory.</p>";
    echo "<p><a href='/phpmotors/vehicles'>Vehicle Management</a></p>";
} 

if(isset($clientReviewsDisplay)){
  echo "<h3 class='reviewHeading'>Manage Your Product Reviews</h3>";
  echo $clientReviewsDisplay;
  }
} ?>

</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>