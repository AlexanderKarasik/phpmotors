<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "$vehicleMake $vehicleModel"; ?> | PHP Motors, Inc.</title>
    <meta
      name="description"
      content="<?php echo "$vehicleMake $vehicleModel"; ?> | PHP Motors, Inc.">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<h1 class='vehicleDetail'><?php echo "$vehicleMake $vehicleModel"; ?></h1>
<section class="vehicleDetail">
    
    <?php if(isset($message)){
    echo $message; }
    ?>
    <!-- Display vehicle's info if it exists -->
    <?php if(isset($vehicleDetailDisplay)){
    echo $vehicleDetailDisplay;
    } ?>
    <!-- Display vehicle's thumbnails if exist -->
    <?php if(isset($thumbDisplay)){
    echo($thumbDisplay);
    } ?>
</section>
<section class='reviews'>
<h2>Customer Reviews</h2>
<?php 
if ($_SESSION['loggedin']){
    echo "<h3>Review the $vehicleMake $vehicleModel</h3>";
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
       }
       
    echo "<div class='addVehicle'>
          <form method='post' action='/phpmotors/reviews/index.php'>
          <label>Screen Name:<input type='text' name='screenName' class='name' readonly value='"; 
          if(isset($screenName)){echo $screenName;} elseif(isset($screenNameSes)){echo $screenNameSes; }; 
          echo "'> </label>
          <label>Review<textarea name='reviewText' required></textarea></label>
          <input type='submit' name='submit' value='Submit Review' class='submitBtn'>  
          <input type='hidden' name='action' value='addReview'> 
          <input type='hidden' name='invId' value='$invId'>
          </form>
          </div>";

}else{
    echo '<p>You must <a href="/phpmotors/accounts?action=login"> login</a> to write a review.</p>';
}
?>

<!-- Display reviews if they exist or prompt to add the first review -->
<div><?php if(isset($vehicleReviewDisplay)){
    echo $vehicleReviewDisplay;
    }else{
        echo "<p><em>Be the first to write a review.</em></p>";
    } ?>
</div>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>