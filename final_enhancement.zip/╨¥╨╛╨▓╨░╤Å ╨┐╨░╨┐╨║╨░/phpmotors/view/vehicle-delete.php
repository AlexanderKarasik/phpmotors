<?php
// Check if the user is logged in and has clientLevel higher than 1. 
// If not, redirect to the home view.
if (!($_SESSION['loggedin']&&($_SESSION['clientData']['clientLevel']>1))) {
  header('Location: /phpmotors');
    exit;
  }
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($invInfo['invMake'])){ 
	echo "Delete $invInfo[invMake] $invInfo[invModel]";} ?> | PHP Motors</title>
    <meta
      name="description"
      content="PHP Motors Add Vehicle Form">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="addVehicle">
<h1>
    <?php if(isset($invInfo['invMake'])){ 
	echo "Delete $invInfo[invMake] $invInfo[invModel]";} ?>
</h1>
<p>Confirm Vehicle Deletion. The delete is permanent.</p>
  <?php
  if (isset($message)) {
  echo $message;
  }
  ?>
<form method="post" action="/phpmotors/vehicles/index.php">
    <label>Make<input type="text" name="invMake" <?php if(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?> readonly></label>
    <label>Model<input type="text" name="invModel" <?php if(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?> readonly></label>
    <label>Description<textarea name="invDescription" readonly><?php if(isset($invInfo['invDescription'])) {echo $invInfo['invDescription']; }?></textarea></label>
    <input type="submit" name="submit" value="Delete Vehicle" class="submitBtn">  
    <input type="hidden" name="action" value="deleteVehicle">  
    <input type="hidden" name="invId" value="<?php if(isset($invInfo['invId'])){ echo $invInfo['invId'];}?>"> 
    </form>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>