<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Registration | PHP Motors</title>
    <meta
      name="description"
      content="Register Form for PHP Motors">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<nav>
<?php echo $navList; ?> 
</nav>

<!-- MAIN GOES HERE -->
<section class="register">
  <?php
  if (isset($message)) {
  echo $message;
  }
  ?>
    <form method="post" action="/phpmotors/accounts/index.php">
        <h1>Register</h1>
            <label class="top">First name<span class="red">*</span> <input type="text" name="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";} ?> required></label>
            <label class="top">Last name<span class="red">*</span><input type="text" name="clientLastname" <?php if(isset($clientLastname)){echo "value='$clientLastname'";} ?> required></label>
            <label class="top">Email<span class="red">*</span> <input type="email" name="clientEmail" <?php if(isset($clientEmail)){echo "value='$clientEmail'";} ?> required></label>
            <p>Password must be at least 8 characters and contain at least 1 number,
                1 capital letter and 1 special character.
            </p>
            <label class="top">Password<span class="red">*</span> <input type="password" name="clientPassword" id="clientPassword" pattern="(?=.*\d)(?=.*\W+)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></label> 
            <button type="button" onclick = showPassword()>Show Password</button>
            <input type="submit" name="submit" value="Register" class="submitBtn">  
            <input type="hidden" name="action" value="register">   
        </form>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
<script>
function showPassword() {
  var x = document.getElementById("clientPassword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</body>
</html>