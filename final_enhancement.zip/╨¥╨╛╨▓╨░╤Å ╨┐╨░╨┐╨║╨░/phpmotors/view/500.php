<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Motors Home Page</title>
    <meta
      name="description"
      content="Server Error | PHP Motors">
    <link href="/phpmotors/css/main.css" rel="stylesheet">
    <link href="/phpmotors/css/snippets.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
  </head>

<body>
<main>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/navigation.php'; ?> 

<!-- MAIN GOES HERE -->
<section class="error">
    <h2>Server Error</h2>
    <p>Sorry our server seems to be experiencing some technical difficulties. 
        Please check back later.
    </p>
</section>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?> 
</main>
</body>
</html>